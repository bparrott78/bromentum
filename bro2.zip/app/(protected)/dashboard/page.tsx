export default function DashboardPage() {
    return (
      <div style={{ padding: "2rem" }}>
        <h1>Welcome to the Dashboard!</h1>
        <p>You are logged in and have a username, so you can see this.</p>
      </div>
    );
  }
